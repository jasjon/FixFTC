﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace FixFTC
{
    public class ColumnRemoval
    {
        private ClientContext _ctx;
        private ContentTypeCollection _cts;
        private List<string> _CTsProcessedViaHierarchy = new List<string>();
        private Dictionary<string, Guid> _cthCols;
        
        private SyndicationResetValues _resetValues;
        private FieldCollection _siteFields;


        private ClientContext GetClientContext(string SiteCollectionURL)
        {
            ClientContext ctx = new ClientContext(SiteCollectionURL);
            if (_resetValues.UsePassword)
            {
                var securePassword = _resetValues.Password;
                System.Net.NetworkCredential _creds = new System.Net.NetworkCredential(_resetValues.UserName, securePassword);

                ctx.Credentials = _creds;
            }
            return ctx;
        }


        public string RemoveSCFields(SyndicationResetValues ResetValues)
        {
            string outputReport = String.Format("Report generated on: {0}\n", DateTime.Now);
            string stage = "Start";
            _resetValues = ResetValues;

            try
            {
                using (_ctx = GetClientContext(_resetValues.ContentTypeHubURL))
                {
                    stage = "Set CTH context";
                    GetContentHubColumnGUIDs();
                    stage = "Retrieved CTH values";
                    outputReport += "GUIDs read from the Hub\n";
                }

                stage = "Processing site collections";
                ProcessSiteCollections(ResetValues, ref outputReport);

                outputReport += "*************** Finished  ***************";
                stage = "Site collections processed";
            }
            catch (Exception ex)
            {
                outputReport += String.Format("\n\nERROR: {0} \n{1}\n\nAt stage: {2}", ex.Message, ex.InnerException, stage);
            }

            return outputReport;
        }

        private void ProcessSiteCollections(SyndicationResetValues ResetValues, ref string outputReport)
        {
            Dictionary<string, string> jobOutput = new Dictionary<string, string>();
            foreach (string siteCollectionURL in _resetValues.SiteCollections)
            {
                ProgressReport scReport = new ProgressReport(siteCollectionURL);
                using (_ctx = GetClientContext(siteCollectionURL))
                {
                    RetreiveContentTypes();
                    scReport.AddEntry("Content types read from target site collection");

                    if (_resetValues.ProcessFields)
                    {
                        scReport.AddEntry("*** Removing field links");
                        jobOutput = RemoveFieldLinks();
                        AddJobOutputToReport(jobOutput, ref scReport);


                        scReport.AddEntry(String.Format("*** Removing Site Columns: {0} columns to process", _cthCols.Keys.Count));
                        jobOutput = RemoveSiteColumns();
                        AddJobOutputToReport(jobOutput, ref scReport);
                    }

                    if (_resetValues.ProcessCTHide)
                    {
                        scReport.AddEntry(String.Format("*** Rename and hiding {0} content types", ResetValues.ContentTypesToRenameAndHide.Count));
                        jobOutput = RenameAndHideContentTypes(ResetValues.ContentTypesToRenameAndHide);
                        AddJobOutputToReport(jobOutput, ref scReport);
                    }

                    if (_resetValues.ProcessCTRemove)
                    {
                        scReport.AddEntry(String.Format("*** Removing {0} content types", ResetValues.ContentTypesToRemove.Count));
                        jobOutput = RemoveContentTypes(ResetValues.ContentTypesToRemove);
                        AddJobOutputToReport(jobOutput, ref scReport);
                    }

                    if (_resetValues.ProcessRefreshCTFlag)
                    {
                        scReport.AddEntry("*** Setting the 'Refresh Content Types' Flag");
                        SetRefreshContentTypesFlag();
                    }

                }
                outputReport += scReport.Output() + "\n";
                outputReport += "-----------------------------------------------------------\n\n";
            }
        }

        private void SetRefreshContentTypesFlag()
        {
            var rootWebProperties = _ctx.Site.RootWeb.AllProperties;
            _ctx.Load(rootWebProperties);
            _ctx.ExecuteQuery();

            if (rootWebProperties["metadatatimestamp"].ToString() != String.Empty)
            {
                rootWebProperties["metadatatimestamp"] = String.Empty;
                _ctx.ExecuteQuery();
            }
        }

        private Dictionary<string, string> RemoveContentTypes(List<string> CTToProcess)
        {
            Dictionary<string, string> jobOutput = new Dictionary<string, string>();
            foreach (string ctName in CTToProcess)
            {
                
                foreach (var ct in _cts)
                {
                    if (ct.Name == ctName)
                    {   
                        try
                        {
                            ct.ReadOnly = false;
                            ct.DeleteObject();
                            _ctx.ExecuteQuery();
                            jobOutput.Add(ct.Name, "Removed content type");
                            break;
                        }
                        catch (Exception ex)
                        {
                            jobOutput.Add(ct.Name, String.Format("Failed to remove content type:\t{0}", ex.Message));
                        }
                    }
                }
            }
            

            return jobOutput;
        }

        private Dictionary<string, string> RenameAndHideContentTypes(List<string> CTToProcess)
        {
            Dictionary<string, string> jobOutput = new Dictionary<string, string>();
            string jobText = String.Empty;
            foreach(string ctToHide in CTToProcess)
            {
                bool alreadyHidden = false;
                foreach (var ct in _cts)
                {
                    if (ct.Name == "Retired_" + ctToHide)
                    {
                        alreadyHidden = true;
                        jobText += String.Format("Content Type '{0}' has already been renamed\n", ctToHide);
                        break;
                    }
                }
                if (! alreadyHidden)
                {
                    foreach (var ct in _cts)
                    {
                        if (ct.Name == ctToHide)
                        {
                            jobText += String.Format("Renaming and hiding {0} type\n", ct.Name);
                            ct.ReadOnly = false;
                            ct.Name = "Retired_" + ct.Name;
                            ct.Hidden = true;
                            ct.Group = "Retired EY Content Types";
                          
                            ct.Update(false);
                            _ctx.ExecuteQuery();

                            ct.ReadOnly = true;
                            _ctx.ExecuteQuery();
                        }
                    }
                }
            }
            
            jobOutput.Add("RenameAndHideContentTypes", jobText);

            return jobOutput;
        }

        private void AddJobOutputToReport(Dictionary<string, string> JobOutput, ref ProgressReport report)
        {
            foreach(string processColumn in JobOutput.Keys)
            {
                report.AddEntry(JobOutput[processColumn]);
            }
        }

        private void GetContentHubColumnGUIDs()
        {
            var cthCols = _ctx.Site.RootWeb.Fields;
            _cthCols = new Dictionary<string, Guid>();
            _ctx.Load(cthCols);
            _ctx.ExecuteQuery();

            foreach (string internalName in _resetValues.FieldNamesToRemove)
            {
                foreach (Field sc in cthCols)
                {
                    if (sc.InternalName == internalName)
                    {
                        _cthCols.Add(internalName, sc.Id);
                        break;
                    }
                }
            }
        }

        private Dictionary<string, string> RemoveSiteColumns()
        {
            Dictionary<string, string> progressReport = new Dictionary<string, string>();
            string columnDiscovery;
            List<Field> siteFields = _siteFields.ToList<Field>();

            foreach (string columnName in _cthCols.Keys)
            {
                columnDiscovery = String.Format("Site column '{0}' Not Found", columnName);
                foreach (Field sfld in siteFields)
                {
                    if (sfld.InternalName == columnName)
                    {
                        if (sfld.Id != _cthCols[columnName]) //Good the local definition is not the same as the Hub
                        {
                            sfld.DeleteObject();
                            _ctx.ExecuteQuery();
                            columnDiscovery = String.Format("Site column '{0}' was deleted", columnName);
                        }
                        else
                        {
                            columnDiscovery = String.Format("Site Column '{0}' shares CTH GUID - not processed", columnName);
                        }
                        
                    }
                }
                progressReport.Add(columnName, columnDiscovery);
            }
            return progressReport;
        }

        private Dictionary<string, string> RemoveFieldLinks()
        {
            Dictionary<string, string> progressReport = new Dictionary<string, string>();
            string columnDiscovery;
            bool columnFound = false;
            foreach (string columnName in _cthCols.Keys)
            {
                columnFound = false;
                columnDiscovery = String.Format("Processing {0}\n", columnName);
                var fieldToRemove = GetFieldToRemove(columnName, _cthCols[columnName]);
                if (fieldToRemove != null)
                {   
                    foreach (var contentType in _cts)
                    {
                        var fieldLinks = contentType.FieldLinks;
                        FieldLink linkToRemove = fieldLinks.FirstOrDefault(l => l.Id == fieldToRemove.Id);
                        if (linkToRemove != null)
                        {
                            //OpenCTHierarchy(contentType.Id.StringValue);
                            linkToRemove.DeleteObject();
                            contentType.Update(false);
                            _ctx.ExecuteQuery();
                            columnDiscovery += String.Format("\tField link '{0}' removed from content type '{1}'\n", columnName, contentType.Name);
                            columnFound = true;
                        }
                    }
                }
                if (columnFound == false)
                {
                    columnDiscovery += String.Format("\tField link '{0}' was not found in any of the Content Types\n", columnName);
                }

                progressReport.Add(columnName, columnDiscovery);
            }

            return progressReport;
        }

        private Field GetFieldToRemove(string FieldName, Guid ContentTypeHubGUID)
        {
            var field = _siteFields.FirstOrDefault(x => x.InternalName == FieldName & x.Id != ContentTypeHubGUID);
            return field;
        }

        

        private void OpenCTHierarchy(string contentTypeId)
        {
            bool updateNeeded = false;

            foreach (var ctToProcess in _cts.Where(x => x.Parent.Id.StringValue == contentTypeId))
            {
                _CTsProcessedViaHierarchy.Add(ctToProcess.Name);
                if (ctToProcess.Sealed == true)
                {
                    ctToProcess.Sealed = false;
                    updateNeeded = true;
                }

                if (ctToProcess.ReadOnly == true)
                {
                    ctToProcess.ReadOnly = false;
                    updateNeeded = true;
                }

                if (updateNeeded)
                {
                    ctToProcess.Update(true);
                    _ctx.ExecuteQuery();
                }

                //recurse ...

                OpenCTHierarchy(ctToProcess.Id.StringValue);
            }


            updateNeeded = false;
            var thisCT = _cts.First(x => x.Id.StringValue == contentTypeId);

            if (thisCT.Sealed == true) { thisCT.Sealed = false; updateNeeded = true; }
            if (thisCT.ReadOnly == true) { thisCT.ReadOnly = false; updateNeeded = true; }
            if (updateNeeded)
            {
                thisCT.Update(true);
                _ctx.ExecuteQuery();
            }
        }

        private void RetreiveContentTypes()
        {
            _siteFields = _ctx.Site.RootWeb.Fields;
            _ctx.Load(_siteFields);
            _cts = _ctx.Site.RootWeb.ContentTypes;
            _ctx.Load(_cts);
            _ctx.ExecuteQuery();

            foreach (var contentType in _cts)
            {
                _ctx.Load(contentType,
                    ct => ct.Parent.Name,
                    ct => ct.Parent.Id,
                    ct => ct.Sealed,
                    ct => ct.Hidden,
                    ct => ct.Id, ct => ct.FieldLinks);
            }
            _ctx.ExecuteQuery();
           

        }

    }        
}
