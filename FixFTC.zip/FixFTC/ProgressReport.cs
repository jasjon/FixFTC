﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FixFTC
{
    class ProgressReport
    {
        private string report;


        public ProgressReport(string SiteCollectionURL)
        {
            string siteCollectionName = SiteCollectionURL.TrimEnd('/').Split('/').Last();

            report = String.Format("CTH Fix for {0}\n", siteCollectionName);
        }

        public void AddEntry(string Entry)
        {
            report += Entry + "\n";
        }

        public string Output()
        {
            return report;
        }
    }
}
